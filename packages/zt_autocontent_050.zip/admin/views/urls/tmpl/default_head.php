<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
    <th width="5">
        <?php echo JText::_('COM_AUTOCONTENT_FEED_HEADING_ID'); ?>
    </th>
    <th width="20">
        <?php echo JHtml::_('grid.checkall'); ?>
    </th>			
    <th>
        <?php echo JText::_('COM_AUTOCONTENT_FEED_FIELD_FEED_NAME_LABEL'); ?>
    </th>
    <th>
        <?php echo JText::_('COM_AUTOCONTENT_FEED_FIELD_FEED_TYPE_LABEL'); ?>
    </th>
    <th>
        <?php echo JText::_('COM_AUTOCONTENT_FEED_FIELD_FEED_CATEGORY_NAME'); ?>
    </th>
    <th>
        <?php echo JText::_('COM_AUTOCONTENT_FEED_FIELD_FEED_PUBLISHED'); ?>
    </th>
</tr>
