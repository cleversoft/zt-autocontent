DROP TABLE IF EXISTS `#__autocontent_feed`;
DROP TABLE IF EXISTS `#__autocontent_log`;