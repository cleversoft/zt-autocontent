<?php
/**
 * Zt Autocontent
 * @package Joomla.Component
 * @subpackage com_autocontent
 * @version 0.5.0
 *
 * @copyright   Copyright (c) 2013 APL Solutions (http://apl.vn)
 *
 */
defined('_JEXEC') or die;
?>
<tr>
    <td colspan="4"><?php echo $this->pagination->getListFooter(); ?></td>
</tr>
